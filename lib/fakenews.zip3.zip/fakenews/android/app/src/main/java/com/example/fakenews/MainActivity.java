package com.example.fakenews;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
