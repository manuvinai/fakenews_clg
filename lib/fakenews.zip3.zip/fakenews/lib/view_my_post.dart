import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class MyPostsPage extends StatefulWidget {
  const MyPostsPage({super.key});

  @override
  State<MyPostsPage> createState() => _MyPostsPageState();
}

class _MyPostsPageState extends State<MyPostsPage> {
  List<String> id_ = <String>[];
  List<String> date_time_ = <String>[];
  List<String> USER_ = <String>[];
  List<String> post_ = <String>[];
  List<String> title_ = <String>[];
  List<String> description_ = <String>[];
  List<String> photo_ = <String>[];

  @override
  void initState() {
    super.initState();
    viewPosts();
  }

  Future<void> viewPosts() async {
    List<String> id = <String>[];
    List<String> date_time = <String>[];
    List<String> USER = <String>[];
    List<String> post = <String>[];
    List<String> title = <String>[];
    List<String> description = <String>[];
    List<String> photo = <String>[];

    try {
      SharedPreferences sh = await SharedPreferences.getInstance();
      String urls = sh.getString('url').toString();
      String lid = sh.getString('lid').toString();
      String url = urls + '/view_my_post'; // API URL from Django

      var data = await http.post(Uri.parse(url), body: {
        'lid': lid, // Replace with actual user id (lid)
      });

      var jsondata = json.decode(data.body);
      String status = jsondata['status'];

      if (status == 'ok') {
        var arr = jsondata["data"];
        for (int i = 0; i < arr.length; i++) {
          id.add(arr[i]['id']?.toString() ?? '');
          date_time.add(arr[i]['date_time']?.toString() ?? '');
          post.add(arr[i]['post']?.toString() ?? '');
          photo.add(arr[i]['photo'] != null ? (urls + arr[i]['photo']) : ''); // Concatenate base URL with photo path
          USER.add(arr[i]['USER']?.toString() ?? '');
          title.add(arr[i]['title']?.toString() ?? '');
          description.add(arr[i]['description']?.toString() ?? '');
        }

        setState(() {
          id_ = id;
          date_time_ = date_time;
          photo_ = photo;
          post_ = post;
          USER_ = USER;
          title_ = title;
          description_ = description;
        });
      }
    } catch (e) {
      print("Error: " + e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Posts'),
        backgroundColor: Colors.blue,
      ),
      body: id_.isEmpty
          ? Center(child: CircularProgressIndicator()) // Show loading spinner while data is fetched
          : ListView.builder(
        itemCount: id_.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    title_[index],
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(description_[index]),
                  SizedBox(height: 8),
                  photo_[index].isNotEmpty
                      ? Image.network(photo_[index])  // Show the image using the URL
                      : Container(
                    height: 200,
                    color: Colors.grey[300],
                    child: Center(
                      child: Icon(
                        Icons.image,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Date: ${date_time_[index]}',
                    style: TextStyle(color: Colors.grey),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Status: ${post_[index]}',
                    style: TextStyle(color: Colors.green),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
