//
// import 'dart:convert';
//
// import 'package:fakenews/chat.dart';
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';
//
// class FriendRequestsPage extends StatefulWidget {
//   @override
//   _FriendRequestsPageState createState() => _FriendRequestsPageState();
// }
//
// class _FriendRequestsPageState extends State<FriendRequestsPage> {
//   bool _isLoading = false;
//   List<dynamic> requests = [];
//   String purl = "";
//
//   @override
//   void initState() {
//     super.initState();
//     _fetchFriendRequests();
//   }
//
//   // Fetch accepted friend requests from the backend
//   Future<void> _fetchFriendRequests() async {
//     final SharedPreferences prefs = await SharedPreferences.getInstance();
//     String? lid = prefs.getString('lid').toString(); // Get the logged-in user ID
//     String? url = prefs.getString('url'); // Get the base URL for the API
//     purl = url.toString();
//     if (lid == null || url == null) {
//       Fluttertoast.showToast(msg: 'User ID or URL not found.');
//       return;
//     }
//
//     setState(() {
//       _isLoading = true;
//     });
//
//     try {
//       final response = await http.post(
//         Uri.parse(url + '/view_accepted_friend_requests'), // Backend endpoint for friend requests
//         body: {
//           'lid': lid, // Send the logged-in user ID
//         },
//       );
//
//       setState(() {
//         _isLoading = false;
//       });
//
//       if (response.statusCode == 200) {
//         var data = jsonDecode(response.body);
//
//         // Check if 'data' is available in the response
//         if (data['data'] != null && data['data'] is List) {
//           setState(() {
//             requests = data['data']; // Store the list of friend requests
//           });
//         } else {
//           Fluttertoast.showToast(msg: 'No accepted friends found.');
//         }
//       } else {
//         Fluttertoast.showToast(msg: 'Error: Failed to load accepted friends.');
//       }
//     } catch (e) {
//       setState(() {
//         _isLoading = false;
//       });
//       Fluttertoast.showToast(msg: 'Error: $e');
//     }
//   }
//
//
//   // Function to handle chat navigation
//   // void _startChat(String friendId, String friendUsername) {
//   //   Navigator.push(
//   //     context,
//   //     MaterialPageRoute(
//   //       builder: (context) => ChatPage(friendId: friendId, friendUsername: friendUsername),
//   //     ),
//   //   );
//   // }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Friend Requests"),
//         backgroundColor: Colors.deepPurple,
//       ),
//       body: _isLoading
//           ? Center(child: CircularProgressIndicator()) // Show loading indicator when fetching requests
//           : requests.isEmpty
//           ? Center(child: Text("No accepted friends found.")) // Show message if no requests
//           : ListView.builder(
//         itemCount: requests.length, // Number of accepted friends
//         itemBuilder: (context, index) {
//           var request = requests[index];
//
//           return Card(
//             margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
//             child: Padding(
//               padding: const EdgeInsets.all(10.0),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Expanded(
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Row(
//                           children: [
//                             CircleAvatar(
//                               radius: 30,
//                               backgroundImage: request['photo'] != null
//                                   ? NetworkImage(purl + request['Image'])
//                                   : AssetImage('assets/default_avatar.png') as ImageProvider,
//                             ),
//                             SizedBox(width: 10),
//                             Column(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 Text(
//                                   request['FROM_id'],
//                                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//                                 ),
//                                 Text(request['email']), // Email or other info
//                                 // Text(request['tid']), // Email or other info
//                               ],
//                             ),
//                           ],
//                         ),
//                       ],
//                     ),
//                   ),
//                   ElevatedButton(
//                     onPressed: () async {
//                       SharedPreferences sh = await SharedPreferences.getInstance();
//                       sh.setString('tid', request['tid'].toString());
//                       Navigator.push(
//                         context,
//                         MaterialPageRoute(builder: (context) => MyChatPage(title: 'Chat with user')),
//                       );
//                     },
//                     style: ElevatedButton.styleFrom(
//                       backgroundColor: Colors.green, // Chat button color
//                       padding: EdgeInsets.symmetric(horizontal: 25, vertical: 12),
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(30),
//                       ),
//                       elevation: 3,
//                     ),
//                     child: Text("Chat", style: TextStyle(color: Colors.white)),
//                   ),
//                 ],
//               ),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }





import 'dart:convert';
import 'package:fakenews/chat.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class FriendRequestsPage extends StatefulWidget {
  @override
  _FriendRequestsPageState createState() => _FriendRequestsPageState();
}

class _FriendRequestsPageState extends State<FriendRequestsPage> {
  bool _isLoading = false;
  List<dynamic> requests = [];
  String purl = "";

  @override
  void initState() {
    super.initState();
    _fetchFriendRequests();
  }

  // Fetch accepted friend requests from the backend
  Future<void> _fetchFriendRequests() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? lid = prefs.getString('lid').toString(); // Get the logged-in user ID
    String? url = prefs.getString('url'); // Get the base URL for the API
    purl = url.toString();
    if (lid == null || url == null) {
      Fluttertoast.showToast(msg: 'User ID or URL not found.');
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final response = await http.post(
        Uri.parse(url + '/view_accepted_friend_requests'), // Backend endpoint for friend requests
        body: {
          'lid': lid, // Send the logged-in user ID
        },
      );

      setState(() {
        _isLoading = false;
      });

      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);

        // Check if 'data' is available in the response
        if (data['data'] != null && data['data'] is List) {
          setState(() {
            requests = data['data']; // Store the list of friend requests
          });
        } else {
          Fluttertoast.showToast(msg: 'No accepted friends found.');
        }
      } else {
        Fluttertoast.showToast(msg: 'Error: Failed to load accepted friends.');
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(msg: 'Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Friend Requests"),
        backgroundColor: Colors.deepPurple,
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator()) // Show loading indicator when fetching requests
          : requests.isEmpty
          ? Center(child: Text("No accepted friends found.")) // Show message if no requests
          : ListView.builder(
        itemCount: requests.length, // Number of accepted friends
        itemBuilder: (context, index) {
          var request = requests[index];

          return Card(
            margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            CircleAvatar(
                              radius: 30,
                              backgroundImage: request['photo'] != null
                                  ? NetworkImage(purl + request['photo'])  // Ensure valid photo URL
                                  : AssetImage('assets/default_avatar.png') as ImageProvider,
                            ),
                            SizedBox(width: 10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  request['FROM_id'] ?? 'Unknown',  // Ensure name is not null
                                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                                ),
                                Text(request['email'] ?? 'No email provided'), // Ensure email is not null
                                Text(request['LOGIN'] ?? 'No email provided'), // Ensure email is not null
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  // ElevatedButton(
                  //   onPressed: () async {
                  //     // Ensure 'tid' is valid before storing it in SharedPreferences
                  //     if (request['tid'] != null) {
                  //       SharedPreferences sh = await SharedPreferences.getInstance();
                  //       sh.setString('tid', request['tid'].toString());
                  //       Navigator.push(
                  //         context,
                  //         MaterialPageRoute(builder: (context) => MyChatPage(title: 'Chat with user')),
                  //       );
                  //     } else {
                  //       Fluttertoast.showToast(msg: 'Unable to start chat. User ID is missing.');
                  //     }
                  //   },
                  //   style: ElevatedButton.styleFrom(
                  //     backgroundColor: Colors.green, // Chat button color
                  //     padding: EdgeInsets.symmetric(horizontal: 25, vertical: 12),
                  //     shape: RoundedRectangleBorder(
                  //       borderRadius: BorderRadius.circular(30),
                  //     ),
                  //     elevation: 3,
                  //   ),
                  //   child: Text("Chat", style: TextStyle(color: Colors.white)),
                  // ),


                  ElevatedButton(
                    onPressed: () async {
                      SharedPreferences sh = await SharedPreferences.getInstance();
                      sh.setString('clid', request['LOGIN'].toString());
                      print(request['LOGIN'].toString());
                      print('id====');

                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => MyChatPage(title: '',)),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      primary: Colors.green, // Set the background color to green
                    ),
                    child: Icon(Icons.chat),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
