import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ViewFriendRequestsPage extends StatefulWidget {
  @override
  _ViewFriendRequestsPageState createState() => _ViewFriendRequestsPageState();
}

class _ViewFriendRequestsPageState extends State<ViewFriendRequestsPage> {
  bool _isLoading = false;
  List<dynamic> requests = [];
  String purl = "";

  @override
  void initState() {
    super.initState();
    _fetchFriendRequests(); // Fetch the friend requests when the page is initialized
  }

  // Fetch pending friend requests from the backend
  Future<void> _fetchFriendRequests() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? lid = prefs.getString('lid'); // Get the logged-in user ID
    String? url = prefs.getString('url'); // Get the base URL for the API
    purl = url.toString();

    if (lid == null || url == null) {
      Fluttertoast.showToast(msg: 'User ID or URL not found.');
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final response = await http.post(
        Uri.parse(url + '/viewfrdrequest'), // Backend endpoint for friend requests
        body: {'lid': lid}, // Send the logged-in user ID
      );

      setState(() {
        _isLoading = false;
      });

      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);

        // Check if 'data' exists in the response and is a List
        if (data['data'] != null && data['data'] is List) {
          setState(() {
            requests = data['data']; // Store the list of friend requests
          });
        } else {
          Fluttertoast.showToast(msg: 'No friend requests found.');
        }
      } else {
        Fluttertoast.showToast(msg: 'Error: Failed to load friend requests.');
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(msg: 'Error: $e');
    }
  }

  // Future<void> _acceptFriendRequest(String tid) async {
  //   final SharedPreferences prefs = await SharedPreferences.getInstance();
  //   String? url = prefs.getString('url').toString();
  //
  //   setState(() {
  //     _isLoading = true;
  //   });
  //
  //   try {
  //     final response = await http.post(
  //       Uri.parse(url + '/and_accept_friendrequest'),
  //       body: {'tid': tid},
  //     );
  //
  //     setState(() {
  //       _isLoading = false;
  //     });
  //
  //     if (response.statusCode == 200) {
  //       var data = jsonDecode(response.body);
  //       if (data['status'] == 'ok') {
  //         Fluttertoast.showToast(msg: 'Friend request accepted.');
  //         // Update the request status in the UI
  //         setState(() {
  //           requests.firstWhere((request) => request['tid'] == tid)['status'] = 'accepted';
  //         });
  //       } else {
  //         Fluttertoast.showToast(msg: 'Failed to accept friend request.');
  //       }
  //     } else {
  //       Fluttertoast.showToast(msg: 'Error: Failed to accept friend request.');
  //     }
  //   } catch (e) {
  //     setState(() {
  //       _isLoading = false;
  //     });
  //     Fluttertoast.showToast(msg: 'Error: $e');
  //   }
  // }
  Future<void> _acceptFriendRequest(String tid) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? url = prefs.getString('url').toString();

    setState(() {
      _isLoading = true;
    });

    try {
      final response = await http.post(
        Uri.parse(url + '/and_accept_friendrequest'),
        body: {'tid': tid},
      );

      setState(() {
        _isLoading = false;
      });

      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        if (data['status'] == 'ok') {
          Fluttertoast.showToast(msg: 'Friend request accepted.');

          // Update the request status in the UI
          setState(() {
            var request = requests.firstWhere((request) => request['tid'] == tid, orElse: () => null);
            if (request != null) {
              request['status'] = 'accepted'; // Update the status
            }
          });
        } else {
          Fluttertoast.showToast(msg: 'Failed to accept friend request.');
        }
      } else {
        Fluttertoast.showToast(msg: 'Error: Failed to accept friend request.');
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(msg: 'Error: $e');
    }
  }

  // Reject friend request
  Future<void> _rejectFriendRequest(String tid) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? url = prefs.getString('url').toString();

    setState(() {
      _isLoading = true;
    });

    try {
      final response = await http.post(
        Uri.parse(url + '/and_reject_friendrequest'),
        body: {'tid': tid},
      );

      setState(() {
        _isLoading = false;
      });

      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        if (data['status'] == 'ok') {
          Fluttertoast.showToast(msg: 'Friend request rejected.');
          // Update the request status in the UI
          setState(() {
            requests.firstWhere((request) => request['tid'] == tid)['status'] = 'rejected';
          });
        } else {
          Fluttertoast.showToast(msg: 'Failed to reject friend request.');
        }
      } else {
        Fluttertoast.showToast(msg: 'Error: Failed to reject friend request.');
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(msg: 'Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Friend Requests"),
        backgroundColor: Colors.deepPurple,
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator()) // Show loading indicator when fetching requests
          : requests.isEmpty
          ? Center(child: Text("No friend requests found.")) // Show message if no requests
          : ListView.builder(
        itemCount: requests.length, // Number of friend requests
        itemBuilder: (context, index) {
          var request = requests[index];

          return Card(
            margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            CircleAvatar(
                              radius: 30,
                              backgroundImage: request['Image'] != null
                                  ? NetworkImage(purl + request['Image'])
                                  : AssetImage('assets/default_avatar.png') as ImageProvider,
                            ),
                            SizedBox(width: 10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  request['Username'],
                                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                                ),
                                Text(request['email']), // Email or other info
                                SizedBox(height: 5),
                                // Text(
                                //   request['status'] ?? 'pending',
                                //   style: TextStyle(
                                //     fontSize: 14,
                                //     color: request['status'] == 'accepted'
                                //         ? Colors.green
                                //         : request['status'] == 'rejected'
                                //         ? Colors.red
                                //         : Colors.grey,
                                //   ),
                                // ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  // Only show accept/reject buttons if the request is pending
                  if (request['status'] == null || request['status'] == 'pending')
                    Row(
                      children: [
                        IconButton(
                          icon: Icon(Icons.check, color: Colors.green),
                          onPressed: () {
                            _acceptFriendRequest(request['tid']);
                          },
                        ),
                        IconButton(
                          icon: Icon(Icons.close, color: Colors.red),
                          onPressed: () {
                            _rejectFriendRequest(request['tid']);
                          },
                        ),
                      ],
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
